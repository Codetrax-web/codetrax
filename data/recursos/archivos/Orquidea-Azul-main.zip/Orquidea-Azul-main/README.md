# 💙 Orquídeas Azules

"La belleza de lo imposible."
Las orquídeas azules son una rareza de la naturaleza y simbolizan exclusividad, admiración y misterio. Este proyecto busca capturar esa esencia mediante una experiencia visual envolvente.
Cada elemento fue diseñado para transmitir elegancia y serenidad a través de tonos azules y animaciones delicadas.

## 💎 Creado por
Damian CV - Codetrax.
